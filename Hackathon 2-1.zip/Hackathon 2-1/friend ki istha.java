import java.util.*;

public class PatientScheduling {
    static int[] queue = new int[100]; 
    static int[] stack = new int[100]; 
    static int[] visitTimes = new int[100];  
    static int queueSize = 0; 
    static int stackSize = 0; 
    static int remainingQueries;
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int q = sc.nextInt(); 
        remainingQueries = q; 
        for (int i = 0; i < q; i++) {
            int type = sc.nextInt(); 
            int patientIndex = sc.nextInt();
            if (type == 1) {
                int visitTime = sc.nextInt();
                queue[queueSize++] = patientIndex;
                visitTimes[patientIndex] = visitTime;
            } else if (type == 2) {
                int visitTime = sc.nextInt();
                stack[stackSize++] = patientIndex;
                visitTimes[patientIndex] = visitTime;
            } else if (type == 3) {
                for (int j = 0; j < queueSize; j++) {
                    if (queue[j] == patientIndex) {
                        stack[stackSize++] = patientIndex;
                        for (int k = j; k < queueSize - 1; k++) {
                            queue[k] = queue[k + 1];
                        }
                        queueSize--;
                        break;
                    }
                }
            } else if (type == 4) {
                int newVisitTime = sc.nextInt();
                visitTimes[patientIndex] = newVisitTime;
            }
            if (remainingQueries <= 3) {
                System.out.println("NO");
            } else {
                if (isGoodConfiguration()) {
                    System.out.println("YES");
                } else {
                    System.out.println("NO");
                }
            }
            
            remainingQueries--;  
        }

        sc.close();
    }
    static boolean isGoodConfiguration() {
        int queueFinishTime = 0; 
        int stackFinishTime = 0; 
        for (int i = 0; i < queueSize; i++) {
            int patient = queue[i];
            int visitTime = visitTimes[patient];
            queueFinishTime += visitTime;
        }
        for (int i = stackSize - 1; i >= 0; i--) {
            int patient = stack[i];
            int visitTime = visitTimes[patient];
            stackFinishTime += visitTime;
            if (isInQueue(patient) && stackFinishTime < queueFinishTime) {
                return false;
            }
        }
        return true;
    }
    static boolean isInQueue(int patient) {
        for (int i = 0; i < queueSize; i++) {
            if (queue[i] == patient) {
                return true;
            }
        }
        return false;
    }
}